﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl.Contracts
{
    public interface IDable
    {
        public string Id { get; }
    }
}
