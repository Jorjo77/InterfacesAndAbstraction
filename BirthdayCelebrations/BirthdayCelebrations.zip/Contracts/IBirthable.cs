﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BirthdayCelebrations.Contracts
{
    public interface IBirthable
    {
        public string Birthdate { get; }
    }
}
